package demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/")
public class MyController {
	@Autowired
	EmpRepo repo;
	@GetMapping(value="/emps")
	public List<Emp> list(){
		    System.out.println("in list");
			return repo.findAll();
	}
}
