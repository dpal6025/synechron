package Day3.Demo2.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
public class MyController {

	@Value("${data: Hello default}")
	String data;
	
	@GetMapping("/")
	public String showDetail() {
		return "<h> Current data ="+data+"</h>";
	}
}
