package day2.demo1.project1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;;

@RestController("/")
public class MyController {

	@Autowired
	EmpRepo repo;
	
	@GetMapping(value="/emps")
	public List<Emp> getEmp(){
		return repo.findAll();
	}
}
