package day2.demo1.project1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories
@EntityScan
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
	
	@Autowired
	EmpRepo repo;
	
	@Bean
	public String insert() {
		for(int i=5;i<10;i++) {
			Emp emp = new Emp();
			emp.setId(i);
			emp.setName("Name of"+i);
			emp.setSalary(i*1000);
			repo.save(emp);
		}
		return "Success";
	}

}
