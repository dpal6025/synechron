package Day2.Demo3.feign;

import java.util.List;

public class UserDetails {

	private int page;
	private int per_page;
	private int total;
	private int total_page;
	private List<User> users;
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getPer_page() {
		return per_page;
	}
	public void setPer_page(int per_page) {
		this.per_page = per_page;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getTotal_page() {
		return total_page;
	}
	public void setTotal_page(int total_page) {
		this.total_page = total_page;
	}
	public List<User> getUsers() {
		return users;
	}
	public void setUsers(List<User> users) {
		this.users = users;
	}
	@Override
	public String toString() {
		return "UserDetails [page=" + page + ", per_page=" + per_page + ", total=" + total + ", total_page="
				+ total_page + ", users=" + users + "]";
	}
	
	
	
}
