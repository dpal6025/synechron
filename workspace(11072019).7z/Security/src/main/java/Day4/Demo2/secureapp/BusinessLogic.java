package Day4.Demo2.secureapp;

import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Component;

@Component
public class BusinessLogic {
	
	@Secured(value = "ROLE_std")
	public void m1() {
		System.out.println("m1 method");
	}
	
	@Secured(value = "ROLE_admin")
	public void m2() {
		System.out.println("m2 method");
	}

	public void m3() {
		System.out.println("m3 method");
	}
}
