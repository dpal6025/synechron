package Day4.Demo2.secureapp;

import javax.sql.DataSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.JdbcUserDetailsManager;

@SpringBootApplication
@EnableGlobalMethodSecurity(prePostEnabled = true,securedEnabled = true)
public class SecurityApplication {
	@Bean
	public DataSource ds() {
		return new DriverManagerDataSource("jdbc:hsqldb:hsql://localhost/", "SA", "");
	}
	
	@Bean
    public UserDetailsService userDetailsService() {
		JdbcUserDetailsManager mgr = new JdbcUserDetailsManager(ds());
		mgr.setUsersByUsernameQuery("select username, password, 'true' as  enabled from users where username=?");
		mgr.setGroupAuthoritiesByUsernameQuery("select users.username, roles.role as role from users, roles where users.username = ?");
		return mgr;		
				
			/*List<UserDetails> list = new ArrayList<>();
	        list.add(User.withUsername("user1").password("{noop}pass1").roles("std").build());
	        list.add(User.withUsername("user2").password("{noop}pass2").roles("admin").build());
	        list.add(User.withUsername("user3").password("{noop}pass3").roles("std","admin").build());
	        return new InMemoryUserDetailsManager(list);
	        */
	    }
	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(SecurityApplication.class, args);
		SecurityContextImpl imp = new SecurityContextImpl();
		Authentication auth = new UsernamePasswordAuthenticationToken("user3", "pass3");
		imp.setAuthentication(auth);
		
		SecurityContextHolder.setContext(imp);
		BusinessLogic bl = ctx.getBean(BusinessLogic.class);
				
		try {
			bl.m1();
		} catch (Exception e) {
			System.out.println("cannot call m1 method" +e);
		}
		
		try {
			bl.m2();
		} catch (Exception e) {
			System.out.println("cannot call m2 method"+e);
		}
		
		try {
			bl.m3();
		} catch (Exception e) {
			System.out.println("cannot call m3 method"+e);
		}
	}

}
