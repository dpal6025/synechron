package Day2.Demo3.hystrix;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;


@RestController
@RequestMapping("/")
public class MyController {

	@GetMapping()
	@HystrixCommand(commandKey="rc", groupKey="proj1", fallbackMethod="showdata_fall")
	public String showdata()
	{
		System.out.println("In showdata");
		RestTemplate template = new RestTemplate();
		String str = template.getForEntity("http://localhost:8080/emps",String.class).getBody();
		return "<h1>Current Data</h1><h2>" + str + "</h2>"  ;
	}

	public String showdata_fall()
	{
		System.out.println("*****in fallback");
	//	RestTemplate template = new RestTemplate();
	//	String str = template.getForEntity("http://localhost:8080/emps",String.class).getBody();
		String str = "{ 'staticdata': 'cached info'	}";
				
		return "<h1>Current Data</h1><h2>" + str + "</h2>"  ;
	}
}
