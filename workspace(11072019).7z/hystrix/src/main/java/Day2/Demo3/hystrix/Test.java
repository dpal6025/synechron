package Day2.Demo3.hystrix;

import java.net.URL;

public class Test {
	public static void main(String[] args) throws Exception{
		for(int i=0;i<50;i++) {
			URL url = new URL("http://localhost");
			url.getContent();
		}
	}
}
