package Day2.Demo3.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name="mycontroller", url="https://reqres.in/api/")
public interface MyController {

	@GetMapping(value="/users?page=2")
	public List<UserDetails> list();
	
	@GetMapping(value="/list")
	public List<Emp> list1();
}
